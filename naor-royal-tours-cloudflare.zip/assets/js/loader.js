/* NAOR ROYAL TOURS · טוען את קבצי האתר בסדר הנכון.
   מצב חסכוני: במצב חיסכון בנתונים, ברשת איטית (2G/3G) או כשספריות התלת־ממד
   והאנימציה (כ-670KB) לא הגיעו תוך 3 שניות, האתר עולה מיד בגרסה הסטטית
   עם אותו תוכן. כך לקוח עם קליטה חלשה לא נשאר מול מסך ריק. */
(function(){
  var d = document.documentElement;
  var c = navigator.connection || navigator.mozConnection || navigator.webkitConnection || {};
  // ?lite=1 in the address shows the light version on purpose (for checking)
  var lite = d.classList.contains('lite') || !!(c.saveData || /(^|-)(2g|3g)$/.test(c.effectiveType || '') || (c.downlink && c.downlink < 1.2) || /[?&]lite=1/.test(location.search));
  if (lite) d.classList.add('lite');

  function add(src, ordered){
    var s = document.createElement('script');
    s.src = src; s.async = !ordered;
    document.body.appendChild(s);
    return s;
  }
  var own = ['assets/js/config.js', 'assets/js/art.js', 'assets/js/main.js', 'assets/js/pack.js', 'assets/js/leads.js'];
  var started = false;
  function loadOwn(){
    if (started) return; started = true;
    // async=false keeps the site's own files in order; the libraries are loaded separately (async),
    // so a slow library never holds the site back
    own.forEach(function(src){ add(src, true); });
  }
  if (lite){ loadOwn(); return; }

  var heavy = ['assets/vendor/three.min.js', 'assets/vendor/gsap.min.js'], left = heavy.length;
  // 3 seconds from the moment the address was opened (not from when this file arrived)
  var timer = setTimeout(function(){ d.classList.add('lite'); loadOwn(); }, Math.max(600, 3000 - (performance.now ? performance.now() : 0)));
  heavy.forEach(function(src){
    var s = add(src, false);
    s.onload = s.onerror = function(){ if (--left === 0){ clearTimeout(timer); loadOwn(); } };
  });
})();
